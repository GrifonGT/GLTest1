package com.sil.grid.gltest.models;

/**
 * Created by Marik on 08.05.2017.
 */

public enum State {
    ALARM_DISARMED_ALL_UNLOCKED, ALARM_DISARMED_DRIVER_UNLOCKED, ALARM_DISARMED_ALL_LOCKED,
    ALARM_ARMED_ALL_LOCKED
}
