package com.sil.grid.gltest.models;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Marik on 08.05.2017.
 */

public class Transition {
    private Map<String, Map<String, String>> transitionMap;

    public Transition(Map<String, Map<String, String>> map) {
        transitionMap = map;
    }

    public State doTransition(Action action, State startState) {
        Log.d("12345", "action: " + action.toString() + " " + (transitionMap.get(action.toString()) == null));
        Map<String, String> ma = transitionMap.get(action.toString());
        Log.d("12345", "startState: " + startState.toString());
        String a = ma.get(startState.toString());
        State st = State.valueOf(a);
        Log.d("12345", a + "   " + st.toString());
        return State.valueOf(transitionMap.get(action.toString()).get(startState.toString()));
    }
}
