package com.sil.grid.gltest.models;

/**
 * Created by Marik on 08.05.2017.
 */

public enum Action {
    LOCK, LOCK_X2, UNLOCK, UNLOCK_X2
}
