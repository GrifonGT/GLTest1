package com.sil.grid.gltest;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.Map;

/**
 * Created by Marik on 08.05.2017.
 */

public class FileParser {
    public static String loadJsonFromFile(Context context) {
        String json;
        try {
            InputStream is = context.getAssets().open("transition.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return json;
    }

    public static Map<String, Map<String, String>> jsonToMap(String json) {
        Type type = new TypeToken<Map<String, Map<String, String>>>() {}.getType();
        Map<String, Map<String, String>> map = new Gson().fromJson(json, type);

        String string = "";
        for (String s : map.keySet()) {
            string += s + ": {";
            Map<String, String> secMap = map.get(s);
            for (String s1 : secMap.keySet()) {
                string += s1 + ": " + secMap.get(s1) + ", ";
            }
            string += "},";
        }
        Log.d("12345", string);

        return map;
    }
}
